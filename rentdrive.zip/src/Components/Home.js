import React from 'react';
import Navbar from '../Navbars/Navbar';
import Carousel from 'react-bootstrap/Carousel'
import Img1 from '../Images/renatal1.png';
import Img2 from '../Images/rental3.jpg';
import Img3 from '../Images/rental5.jpg';
class Home extends React.Component{
    render()
    {
        return(
             <div>
                <Navbar/>
                    <div >
                    <h2 className="text-dark text-center pt-2">Lets's Hire Your Drive</h2>
                    <Carousel>
                        <Carousel.Item interval={1000}>
                            <img
                                className="d-block w-100"
                                src={Img1}
                                alt="First slide"
                            />
                            <Carousel.Caption>
                                <h3 className='text-dark'>Need A Vehicle On Rent?</h3>
                                <p></p>
                            </Carousel.Caption>
                        </Carousel.Item>
                        <Carousel.Item interval={1000}>
                            <img
                                className="d-block w-100"
                                src={Img2}
                                alt="Second slide"
                            />
                            <Carousel.Caption>
                             <h3>Have It On Finger Tips </h3>
                            <p></p>
                            </Carousel.Caption>
                        </Carousel.Item>
                        <Carousel.Item interval={1000}>
                            <img
                            className="d-block w-100"
                            src={Img3}
                            alt="Third slide"
                            />
                            <Carousel.Caption>
                            <h3>Rent A Safe Drive</h3>
                            <p></p>
                        </Carousel.Caption>
                        </Carousel.Item>
                    </Carousel>
                    <h2 className="text-primary text-center pt-2">Rent A Car Or Truck</h2>
                    <h2 className="text-primary text-center pt-2">Get Your Favorite here</h2>
                    <h2 className="text-primary text-center pt-2">Travel Hastle free</h2>
            </div>
        </div>
        );
    }
}
export default Home;