import React from 'react';
import LoginNavbar from '../Navbars/LoginNavbar';
import AdminService from '../Service/AdminService';
import Alert from 'react-bootstrap/Alert';
import { Redirect } from 'react-router';

class AdminFunctions extends React.Component
{
     constructor(props)
    {
        super(props);
        const token = localStorage.getItem("token");

        let loggedIn = true;
        if(token==null)
        {
            loggedIn=false;
        }
        this.state={
            id : localStorage.getItem("token"),
            type : '',
            brand : '',
            user : {},
            vehiclelist : [],
            loggedIn
        }
        this.getVehicles=this.getVehicles.bind(this);
        this.changeBrandHandler= this.changeBrandHandler.bind(this);
        this.changeTypeHandler = this.changeTypeHandler.bind(this);
        this.searchByType=this.searchByType.bind(this);
        this.searchByBrand=this.searchByBrand.bind(this);
    }
    componentDidMount()
    {
        AdminService.getUser(this.state.id).then( (res) => {
            this.setState({ user: res.data});
        })
    }
    changeTypeHandler= (event) => {
        this.setState({type: event.target.value});
    }
    changeBrandHandler= (event) => {
        this.setState({brand: event.target.value});
    }

    searchByBrand(brand){
        this.props.history.push('/vehicleByBrand/'+ brand);
    }

    searchByType(type){

        console.log('In home :'+type);
        console.log(type);
        this.props.history.push('/vehicleByType/'+ type);
       
    } 
    getVehicles(){
        this.props.history.push('/getVehicles');
    }

    render(){
        if(this.state.loggedIn===false){
            return <Redirect to="/login"/>
        }
        return(
            <div>
                <LoginNavbar/>
            <div className="container">
                <Alert variant="success">Welcome Admin {this.state.user.name}</Alert>
            
                <form className="mt-3">
                
                <button className="mb-2 mr-sm-2 btn btn-primary" onClick={() => this.getVehicles()}>All Vehicles</button>

                <input type="text" className="mb-2 mr-sm-2" placeholder="Enter Vehicle Type" name="type"
                 value={this.state.type} onChange={this.changeTypeHandler} />
                <button className="btn btn-primary mr-sm-2"  onClick={() => this.searchByType(this.state.type)}>Search</button>

                <input type="text" className="mb-2 mr-sm-2" placeholder="Enter Vehicle Brand" name="brand"
                 value={this.state.brand} onChange={this.changeBrandHandler} />
                <button className="btn btn-primary mr-sm-2" onClick={() => this.searchByBrand(this.state.brand)} >Search</button>
               
                </form>
            </div>
            </div>
        )
    }
}
export default AdminFunctions;