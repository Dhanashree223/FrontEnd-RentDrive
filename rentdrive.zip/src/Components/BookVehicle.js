import React, { Component } from 'react';
import UserService from '../Service/UserService';
import Navbar from '../Navbars/Navbar';
import LoginNavbar from '../Navbars/LoginNavbar';

class BookVehicle extends Component {
    constructor(props) {
        super(props)
        const token = localStorage.getItem("token");

        let loggedIn = true;
        if(token==null)
        {
            loggedIn=false;
        }

        this.state = {
            vehicleId: this.props.match.params.vehicleId,
            userId : localStorage.getItem("token"),
            loggedIn,
            vehicle: {},
            user : {},
            fromDate : '',
            toDate : ''
        }
        this.bookVehicle=this.bookVehicle.bind(this);
    }

    componentDidMount(){
        UserService.getVehicle(this.state.vehicleId).then( res => {
            this.setState({vehicle: res.data});
        });
        UserService.getUser(this.state.userId).then( res => {
            this.setState({user: res.data});
        });
        
    }

    changeFromDateHandler= (event) => {
        this.setState({fromDate: event.target.value});
    }

    changeToDateHandler= (event) => {
        this.setState({toDate: event.target.value});
    }

    bookVehicle = (e) => {
        e.preventDefault();
        let booking = {
                            user: this.state.user,
                            vehicle: this.state.vehicle,
                            toDate : this.state.toDate,
                            fromDate : this.state.fromDate
                        };
        console.log('booking => ' + JSON.stringify(booking));
    
        UserService.bookVehicle(booking).then( (res) =>{
            alert("Your Booking is done... Wait for Confirmation");
        });
        
    }

    back(){
        this.props.history.goBack();
    }

    render() {
        return (
            <div> 
                {this.state.loggedIn && <LoginNavbar/>} 
                {!this.state.loggedIn && <Navbar/>}  
                <br></br>
                <div className = "card col-md-6 offset-md-3">
                    <h3 className = "text-center"> Book Vehicle </h3>
                    <div className = "card-body">
                        <div className = "row">
                            <div className="form-group">
                                <label>From Date:</label>
                                <input type="date" className="form-control" placeholder="From Date" 
                                value={this.state.email} onSelect={this.changeFromDateHandler}/>
                            </div>
                        </div>
                        <div className = "row">
                            <div className="form-group">
                                <label>To Date:</label>
                                <input type="date" className="form-control" placeholder="To Date" 
                                value={this.state.password} onSelect={this.changeToDateHandler}/>
                            </div>
                        </div>
                        <div className = "row">
                            <button onClick={ () => this.back()} 
                                className="btn btn-primary"> Back </button>
                            <button  onClick={this.bookVehicle} 
                                className="btn btn-primary ml-3"> Confirm Booking </button>
                        </div>
                    </div>

                </div>
            </div>
        )
    }
}

export default BookVehicle;