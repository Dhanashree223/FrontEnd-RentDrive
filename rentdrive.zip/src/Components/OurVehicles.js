import React from 'react';
import Navbar from '../Navbars/Navbar';
class OurVehicles extends React.Component{
    constructor(props)
    {
        super(props);
        this.state = {
            type : '',
            brand : ''
        }
        this.getVehicles=this.getVehicles.bind(this);
        this.changeBrandHandler= this.changeBrandHandler.bind(this);
        this.changeTypeHandler = this.changeTypeHandler.bind(this);
        this.searchByType=this.searchByType.bind(this);
        this.searchByBrand=this.searchByBrand.bind(this);
    }
    changeTypeHandler= (event) => {
        this.setState({type: event.target.value});
    }
    changeBrandHandler= (event) => {
        this.setState({brand: event.target.value});
    }

    searchByBrand(brand){
        this.props.history.push('/vehicleByBrand/'+ brand );
    }

    searchByType(type){

        console.log('In home :'+type);
        console.log(type);
        this.props.history.push('/vehicleByType/'+ type);
       
    } 
    getVehicles(){
        this.props.history.push('/getVehicles');
    }
    render()
    {
        return(
             <div>
                <Navbar/>
                <div className="container">
                <form className="mt-3">
                
                <button className="mb-2 mr-sm-2 btn btn-primary" onClick={() => this.getVehicles()}>All Vehicles</button>

                <input type="text" className="mb-2 mr-sm-2" placeholder="Enter Vehicle Type" name="type"
                 value={this.state.type} onChange={this.changeTypeHandler} />
                <button className="btn btn-primary mr-sm-2"  onClick={() => this.searchByType(this.state.type)}>Search</button>

                <input type="text" className="mb-2 mr-sm-2" placeholder="Enter Vehicle Brand" name="brand"
                 value={this.state.brand} onChange={this.changeBrandHandler} />
                <button className="btn btn-primary mr-sm-2" onClick={() => this.searchByBrand(this.state.brand)} >Search</button>
               
                </form>
                </div>
            </div>
        );
    }
}
export default OurVehicles;