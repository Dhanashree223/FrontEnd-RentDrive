import React from 'react';
import Navbar from '../Navbars/Navbar';
import Alert from 'react-bootstrap/Alert';

class Login extends React.Component{

    constructor(props) {
        super(props);
        localStorage.removeItem("token");
    }

    render()
    {
        return(
            <div>
                <Navbar/>
            <div className="container">
                <Alert variant="success">Logged-Out Successfully....</Alert>
            </div>
            </div>
        );
    }
}
export default Login;