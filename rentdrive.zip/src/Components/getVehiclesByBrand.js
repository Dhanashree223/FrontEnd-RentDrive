import React from 'react';
import UserService from '../Service/UserService';
import LoginNavbar from '../Navbars/LoginNavbar';
import Navbar from '../Navbars/Navbar';

class GetVehiclesByBrand extends React.Component
{
    constructor(props)
    {
        super(props);
        const token = localStorage.getItem("token");

        let loggedIn = true;
        if(token==null)
        {
            loggedIn=false;
        }
        this.state={
            brand: this.props.match.params.brand,
            id : this.props.match.params.id,
            vehicleList : [],
            loggedIn
        }
    }
    componentDidMount(){
        UserService.getVehiclesByBrand(this.state.brand).then((res) => {
            this.setState({ vehicleList: res.data});

        });
    }
    
    viewVehicle(vehicleId){
        this.props.history.push('/viewVehicle/'+ vehicleId);
    }
    
    bookVehicle(vid){
        this.props.history.push(`/viewVehicle/${vid}`);
    }


    back(){
        this.props.history.goBack();
    }
    render()
    {
        return(
            <div>
                {this.state.loggedIn && <LoginNavbar/>} 
                {!this.state.loggedIn && <Navbar/>}  
            <div className="container">
            <h2 className="text-center mt-2">Vehicle List</h2>
             <div className = "row">
                    <table className = "table table-striped table-bordered mt-2">

                        <thead>
                            <tr>
                                <th> Vehicle Id</th>
                                <th> Vehicle Type</th>
                                <th> Vehicle Brand</th>
                                <th> Vehicle Number</th>
                                <th> Actions </th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.vehicleList.map(
                                    vehicle => 
                                    <tr key = {vehicle.vid}>
                                         <td> {vehicle.vid} </td>   
                                         <td> {vehicle.vtype}</td>
                                         <td> {vehicle.vbrand}</td>
                                         <td> {vehicle.vnumber}</td>
                                         <td>
                                                <button style={{marginLeft: "10px"}} 
                                                onClick={ () => this.viewVehicle(vehicle.vid)} 
                                                className="btn btn-primary"> View </button>

                                                <button disabled={!this.state.loggedIn} style={{marginLeft: "10px"}} 
                                                onClick={ () => this.bookVehicle(vehicle.vid)} 
                                                className="btn btn-primary"> Book </button>
                                          </td>
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
                <button className="btn btn-primary mr-sm-2" onClick={() => this.back()}>Back</button>
            </div>
        </div>
        )
    }
}
export default GetVehiclesByBrand;