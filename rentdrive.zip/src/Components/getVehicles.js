import React from 'react';
import UserService from '../Service/UserService';
import Navbar from '../Navbars/Navbar';
import LoginNavbar from '../Navbars/LoginNavbar';

class GetVehicles extends React.Component {

    constructor(props)
    {
        super(props);
        const token = localStorage.getItem("token");

        let loggedIn = true;
        if(token==null)
        {
            loggedIn=false;
        }
        this.state={
            id : localStorage.getItem('token'),
            vehicles : [],
            loggedIn
        }
        
    }

    componentDidMount(){
        console.log("Login State :"+this.state.loggedIn);
        UserService.getVehicles().then((res) => {
            this.setState({ vehicles: res.data});
        });
    } 

    viewVehicle(vehicleId){
        this.props.history.push('/viewVehicle/'+ vehicleId);
    }

    bookVehicle(vid){
        this.props.history.push(`/viewVehicle/${vid}`);
    }


    back(){
        this.props.history.goBack();
    }
 
    render()
    {
        return(
           
            <div>  
                {this.state.loggedIn && <LoginNavbar/>} 
                {!this.state.loggedIn && <Navbar/>}  
             <div className="container">
             <h2 className="text-center mt-2">Vehicle List</h2>
              <div className = "row">
                     <table className = "table table-striped table-bordered mt-2">

                         <thead>
                             <tr>
                                 <th> Vehicle Id</th>
                                 <th> Vehicle Type</th>
                                 <th> Vehicle Brand</th>
                                 <th> Vehicle Number</th>
                                 <th> Actions </th>
                             </tr>
                         </thead>
                         <tbody>
                             {
                                 this.state.vehicles.map(
                                     vehicle => 
                                     <tr key = {vehicle.vid}>
                                          <td> {vehicle.vid} </td>   
                                          <td> {vehicle.vtype}</td>
                                          <td> {vehicle.vbrand}</td>
                                          <td> {vehicle.vnumber}</td>
                                          <td>
                                                <button style={{marginLeft: "10px"}} 
                                                onClick={ () => this.viewVehicle(vehicle.vid)} 
                                                className="btn btn-primary"> View </button>

                                                <button disabled={!this.state.loggedIn} style={{marginLeft: "10px"}} 
                                                onClick={ () => this.bookVehicle(vehicle.vid)} 
                                                className="btn btn-primary"> Book </button>
                                          </td>
                                     </tr>
                                 )
                             }
                         </tbody>
                     </table>
                    </div>
                    <button className="btn btn-primary" onClick={() => this.back()}>Back</button>
            </div>
            </div> 
         
        )
    }
}

export default GetVehicles;